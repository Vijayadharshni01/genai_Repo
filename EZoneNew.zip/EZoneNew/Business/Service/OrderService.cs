using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using EZone.Models;
using EZone.Business.Interface;
using EZone.Repositories.Interface;
using EZone.Repositories.Service;
using EZone.Data;
using Microsoft.EntityFrameworkCore;
namespace EZone.Business.Service
{
    public class OrderService : IOrderService
    {
        private readonly ICartRepository _cartRepo;
        private readonly IOrderRepository _orderRepo;
        private readonly AppDbContext _db;


        public OrderService(ICartRepository cartRepo, IOrderRepository orderRepo, AppDbContext db)
        {
                _cartRepo = cartRepo;
                _orderRepo = orderRepo;
                _db = db;
        }


        public async Task<Order> PlaceOrderAsync(int userId, string paymentMethod)
        {
        var cart = (await _cartRepo.GetCartForUserAsync(userId)).ToList();
        if (!cart.Any()) throw new InvalidOperationException("Cart is empty");


        decimal total = cart.Sum(c => c.Product.Price * c.Quantity);
        var order = new Order
        {
        UserId = userId,
        PaymentMethod = paymentMethod,
        TotalAmount = total,
        OrderItemsJson = JsonConvert.SerializeObject(cart.Select(c => new { c.ProductId, c.Product.Name, c.Quantity, c.Product.Price }))
        };


        var created = await _orderRepo.CreateAsync(order);
        await _cartRepo.ClearCartAsync(userId);
        return created;
        }


        public Task<IEnumerable<Order>> GetOrdersAsync(int userId){
            return _orderRepo.GetByUserAsync(userId);
        }
    }
}
