using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;

namespace EZone.Business.Interface
{
    public interface ICartService
    {
        Task<IEnumerable<Cart>> GetCartAsync(int userId);
        Task<Cart> AddOrUpdateAsync(int userId, int productId, int quantity);
        Task<bool> RemoveAsync(int cartItemId);
        Task ClearCartAsync(int userId);
    }
}