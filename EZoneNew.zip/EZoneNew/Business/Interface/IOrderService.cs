using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EZone.Models;
namespace EZone.Business.Interface
{
    public interface IOrderService
    {
        Task<Order> PlaceOrderAsync(int userId, string paymentMethod);
        Task<IEnumerable<Order>> GetOrdersAsync(int userId);
    }
}