using Microsoft.AspNetCore.Mvc;
using EZone.Models;
using EZone.Business.Interface;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace EZone.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductsController(IProductService service)
        {
            _service = service;
        }

        // 1. Show all products
        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _service.GetAllAsync());

        // 2. Search product by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var product = await _service.GetByIdAsync(id);
            if (product == null)
                return NotFound();
            return Ok(product);
        }

        // 3. Add product
        [Authorize(Roles = "Merchant")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Product product)
        {
            return Ok(await _service.CreateAsync(product));
        }

        // 4. Update product by ID
        [Authorize(Roles = "Merchant")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Product product)
        {
            if (id != product.Id)
                return BadRequest("Product ID mismatch.");
            return Ok(await _service.UpdateAsync(product));
        }

        // 5. Delete product by ID
        [Authorize(Roles = "Merchant")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            return Ok(await _service.DeleteAsync(id));
        }
    }
}