using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EZone.Business.Interface;
using EZone.Business.Service;
namespace EZone.Controllers
{
        [ApiController]
        [Route("api/[controller]")]
        public class CartController : ControllerBase
        {
        private readonly ICartService _cartService;
        public CartController(ICartService cartService){
            _cartService = cartService;
        }

        [HttpGet("{userId}")]
        public async Task<IActionResult> GetCart(int userId){
            return Ok(await _cartService.GetCartAsync(userId));
        }

        [HttpPost("{userId}/add")]
        public async Task<IActionResult> AddToCart(int userId, [FromQuery] int productId, [FromQuery] int qty = 1)
        {
        var item = await _cartService.AddOrUpdateAsync(userId, productId, qty);
        return Ok(item);
        }

        [HttpDelete("{cartItemId}")]
        public async Task<IActionResult> Remove(int cartItemId){
            return Ok(await _cartService.RemoveAsync(cartItemId));
        }
    }
}