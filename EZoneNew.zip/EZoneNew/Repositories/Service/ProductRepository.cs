using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EZone.Repositories.Interface;
using EZone.Data;
using EZone.Models;

namespace EZone.Repositories.Service
{
    public class ProductRepository : IProductRepository
    {
        private readonly AppDbContext _db;
        public ProductRepository(AppDbContext db){
             _db = db;
        }   


        public async Task<Product> AddAsync(Product product)
        {
            _db.Products.Add(product);
            await _db.SaveChangesAsync();
            return product;
        }


        public async Task<bool> DeleteAsync(int id)
        {
            var p = await _db.Products.FindAsync(id);
            if (p == null) return false;
            _db.Products.Remove(p);
            await _db.SaveChangesAsync();
            return true;
        }


        public async Task<IEnumerable<Product>> GetAllAsync(){
            return await _db.Products.ToListAsync();
        }


        public async Task<Product> GetByIdAsync(int id){
            return await _db.Products.FindAsync(id);
        }


        public async Task<Product> UpdateAsync(Product product)
        {
            _db.Products.Update(product);
            await _db.SaveChangesAsync();
            return product;
        }       
    }
}