using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EZone.Repositories.Interface;
using EZone.Data;
using EZone.Models;

namespace EZone.Repositories.Service
{
    public class OrderRepository : IOrderRepository
    {
        private readonly AppDbContext _db;
            public OrderRepository(AppDbContext db){ 
                _db = db;
            }
            public async Task<Order> CreateAsync(Order order)
            {
                _db.Orders.Add(order);
                await _db.SaveChangesAsync();
                return order;
            }


            public async Task<IEnumerable<Order>> GetByUserAsync(int userId){
                return await _db.Orders.Where(o => o.UserId == userId).ToListAsync();
            }
    }
}