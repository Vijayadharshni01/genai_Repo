using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Text;
namespace EZone.Security
{
    public class SimplePasswordHasher : IPasswordHasher
    {
        private const int SaltSize = 16; // bytes


        public string Hash(string password)
        {
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(password).Concat(salt).ToArray());
        return Convert.ToBase64String(salt) + "." + Convert.ToBase64String(hash);
        }


        public bool Verify(string password, string hash)
        {
        var parts = hash.Split('.');
        if (parts.Length != 2) return false;
        var salt = Convert.FromBase64String(parts[0]);
        var expected = parts[1];
        var actualHash = SHA256.HashData(Encoding.UTF8.GetBytes(password).Concat(salt).ToArray());
        return Convert.ToBase64String(actualHash) == expected;
        }
    }
}