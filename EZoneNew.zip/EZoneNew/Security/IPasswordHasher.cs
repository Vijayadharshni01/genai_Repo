using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EZone.Security
{
    public interface IPasswordHasher
    {
        string Hash(string password);
        bool Verify(string password, string hash);
    }
}